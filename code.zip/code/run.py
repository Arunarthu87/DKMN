# import lifetime as lifetime
import numpy, random
import HMO


def func(rounds, nodes, n_cluster, energy, data_pack,neigh, x_value, y_value, bs, i, pop, xt, xr, col_n,
         simulation_result, dist,ps):
    Enery_dep, Overall_dep = [], []
    # distance between nodes
    def distance(p1, p2):
        dist = numpy.sqrt((numpy.square(x_value[p2] - x_value[p1])) + (numpy.square(y_value[p2] - y_value[p1])))
        return dist

    # calculate depletion
    def calc_depletion(np_):
        # energy drop for all nodes
        for ed in range(np_):
            y = data_pack[ed]  # Packet
            Es = (440 * 5) * (y / 6e6)
            Enery_dep.append(Es)
            Overall_dep.append(1 - Es)

    def Direct_trust(nodes, ED, Overall_dep, FP):

        DT = 1 - ((Overall_dep[nodes]) - ED[nodes] * FP[nodes]) / (Overall_dep[nodes])
        return DT

    def Indirect_trust(neigh_node, node, DT):

        dt_nc_i = 0
        for i in range(len(neigh_node) - 1):
            dt_nc_i += DT[neigh_node[i]] * DT[node]
        dt_i = 0
        for i in range(len(neigh_node) - 1):
            dt_i += DT[neigh_node[i]]
        IT = dt_nc_i / dt_i
        return IT

    def Recent_trust(node, DT, IT):
        Beta = 0.5  # weight of direct throughput
        RT = Beta * DT[node] + (1 - Beta) * IT[node]
        return RT

    def calc_trust(node_neigh, nodes, Enery_dep, Overall_dep, ps, throughput):
        DT, IT, RT, AF = [], [], [], []
        for i in range(nodes):
            DT.append(Direct_trust(i, Enery_dep, Overall_dep, ps))
        for i in range(nodes):
            IT.append(Indirect_trust(node_neigh[i], i, DT))
        for j in range(nodes):
            RT.append(Recent_trust(j, DT, IT))
        HT = Historical_trust(throughput, RT, nodes)
        T = []
        for ij in range(nodes):
            t = ((1 / 4) * (DT[ij]) + IT[ij] + RT[ij] + HT[ij] ) # trust
            T.append(throughput[ij] - t)
        trust = T.copy()
        return trust

    def Historical_trust(ht, RT, nodes):

        p = random.uniform(0, 1)
        HT = []
        for i in range(nodes):
            HT.append((p * (ht[i]) + RT[i]) / 2)
        return HT

    # calculate node energy
    def calc_node_en(np, prev_en, x_t, x_r):

        en = prev_en.copy()  # copy of previous round energy
        m, n = 0.0005, 1000  # normalizing factor

        # energy drop for all nodes
        for ed in range(len(np) - 1):
            y = data_pack[abs(int(np[ed]))]  # no. of transmitted bits
            if ed == 0:  # source node
                if en[np[ed]] > 0:
                    dt = distance(np[ed], np[ed + 1]) / n  # distance to send the data
                    E = en[np[ed]] - (x_t * y) * dt  # only send the data to head
                    if E > 0: en[np[ed]] = E
                    else: en[np[ed]] = 0
                else:
                    en[np[ed]] = 0

            else:  # other nodes in path
                if np[ed] > 0:  # if 0 then no path
                    if en[np[ed]] > 0:
                        dt, dr = distance(np[ed], np[ed + 1]) / n, distance(np[ed], np[ed - 1]) / n  # distance to send & receive the data
                        E = en[np[ed]] - (x_r * y) * dr - (x_t * y) * dt  # receive & send
                        if E > 0: en[np[ed]] = E
                        else: en[np[ed]] = 0
                    else:
                        en[np[ed]] = 0
        return en


    # Group with Cluster Head
    def node_clustering(n, CH):
        clustered = []
        for i in range(n):
            tem = []  # tem array to store the distance value
            for j in range(len(CH)):
                tem.append(
                    distance(i, CH[j]))  # distance calculation between cluster head & nodes except base station
            min_index = numpy.argmin(tem)
            clustered.append(CH[min_index])  # grouped cluster head is added
        clustered.append(bs)  # added base station at last separately
        return clustered

    # Cluster Head selection
    def CH_selection(en, opt):
        data = []
        for i in range(len(x_value)):
            tem = []
            tem.append(x_value[i]), tem.append(y_value[i])
            data.append(tem)
        CH = random.sample(opt, n_cluster)      # cluster Head
        return CH

    def get_dis(path):
        d = []
        path = list(map(int, path))
        for i in range(len(path) - 1):
            dist = numpy.sqrt((numpy.square(x_value[path[i + 1]] - x_value[path[i]])) + (
                numpy.square(y_value[path[i + 1]] - y_value[path[i]])))
            d.append(dist)
        return d

    # Pth detection
    def detection(opt_nodes, base, en, pn, n_c, nodes, data):

        pth = []
        pth.append(0)  # source
        if(n_c>len(opt_nodes)): n_c = len(opt_nodes)    # non dead nodes

        # Cluster Head selection
        cluster_head = CH_selection(en, opt_nodes)
        grp = node_clustering(nodes, cluster_head)  # cluster head of the nodes

        # Path detection by Proposed   optimization
        opt_path = HMO.algm(n_cluster, cluster_head, energy, bs, rounds, nodes, dist, neigh, data_pack,x_value,y_value)
        for op in range(len(opt_path)):
            pth.append(int(opt_path[op]))

        pth.append(base)  # destination
        pth = numpy.unique(pth)
        pth.sort()
        return cluster_head, grp, pth.tolist()

    def calc_node_de_tp(en, data):
        de, tp = [], []
        n_packet, packet_received = 0, 0  # total packets, packets received
        for dt in range(len(en)):  # to the size of the node
            r = random.uniform(-1, 1)
            row = numpy.abs(((1.0 - en[dt]) * data[dt]) + r)
            lam = data[dt]
            n_packet = n_packet + data[dt]
            packet_received = packet_received + (en[dt] * data[dt])
            tp.append((en[dt] * data[dt]) / data[dt])
            d = row / lam
            if (d < 1):
                de.append(d)
            else:
                de.append(1)
        return de, tp

    def network_Lifetime(en, data):
        nl = []
        n_packet, packet_received = 0, 0  # total packets, packets received
        for dt in range(len(en)):  # to the size of the node
            r = random.uniform(0.75, 0.95)
            row = numpy.abs(((1.0 - en[dt]) * data[dt]) + r)
            lam = data[dt]
            n_packet = n_packet + data[dt]
            packet_received = packet_received + (en[dt] * data[dt])

            d = row / lam
            if (d < 1):
                nl.append(d)
            else:
                nl.append(r)
        return nl


    # nodes other than dead nodes
    def get_active_nodes(en):
        opt_n = []
        for o in range(len(en)):
            if (o > 0) and (en[o] > 0):  # node with energy(not the dead node)
                opt_n.append(o)  # nodes other than source & destination
        return opt_n

    def get_dead_nodes(en):
        opt_n = []
        for o in range(len(en)):

                opt_n.append(int(en[o]))  # nodes other than source & destination
        return opt_n

    dead_nodes = get_dead_nodes(energy)

    ### dead
    # get non dead nodes
    opt_nodes = get_active_nodes(energy)

    # Path from source to destination
    round_energy =  energy.copy()
    if(len(opt_nodes) > 0):
        ch, cluster_group, path = detection(opt_nodes, bs, energy, pop, n_cluster, nodes, data_pack)
        calc_depletion(nodes)
        round_energy = calc_node_en(path, energy, xt, xr)  # energy of nodes after the transmission
        round_delay, round_throughput = calc_node_de_tp(energy, data_pack)
        round_nl = network_Lifetime(dead_nodes, data_pack)
        round_trust = calc_trust(neigh, nodes, Enery_dep, Overall_dep, ps, round_throughput)
        round_dis = get_dis(path)

    if (i == rounds-1):
        dead_node = []  # nodes with no energy
        for j in range(len(round_energy)):
            if (round_energy[j] == 0):
                dead_node.append(j)

        simulation_result.append(x_value)   # nodes x-axis value
        simulation_result.append(y_value)   # nodes y-axis value
        simulation_result.append(n_cluster) # no. of cluster heads
        simulation_result.append(i)         # no. of rounds
        simulation_result.append(bs)        # Base station
        simulation_result.append(col_n)     # no. of grid columns in simulation window
        simulation_result.append(ch)        # Cluster head nodes
        simulation_result.append(cluster_group)  # nodes grouped with cluster heads
        simulation_result.append(dead_node)  # dead nodes (nodes with energy 0)
        simulation_result.append(path)       # transmission path of last node
    return round_energy, round_dis, round_trust
