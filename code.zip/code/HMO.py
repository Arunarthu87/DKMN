import random

import numpy as np
import fitness1

# Objective function to minimize
def objective_function(x):
    return np.sum(x ** 2)

# Initialize the hunting group
def initialize_population(hgs, dim, lower_bound, upper_bound):
    return np.random.uniform(lower_bound, upper_bound, (hgs, dim))


# Evaluate population
def evaluate_population(population):
    return np.array([objective_function(ind) for ind in population])


# Moving toward the leader
def move_toward_leader(population, leader, mml):
    a1,a2=2,5
    pb=random.uniform(0,1)
    gb = random.uniform(0, 1)
    new_population = population.copy()
    for i in range(len(population)):
        for j in range(len(population[i])):
            rand_uniform = np.random.uniform(0, 1)
            # updated eq
            new_position = (1/(a1+a2-mml)) * ((population[i][j] + a1 * pb + a2 * gb) * (1-mml) - (rand_uniform + mml * population[i][j]) * (1 - a1 - a2))
            # Check if new position is better
            if objective_function(new_position) < objective_function(population[i][j]):
                new_population[i][j] = new_position
            else:
                new_population[i][j] = population[i][j]  # Keep the previous position if not better
    return new_population


# Position correction
def position_correction(population, hgcr,upper_bound,lower_bound):
    corrected_population = population.copy()
    for i in range(len(population)):
        for j in range(len(population[i])):
            if np.random.uniform(0, 1) < hgcr:
                corrected_population[i][j] = population[np.random.randint(0, len(population))][j]
            else:
                ra = np.random.uniform(0, 1)
                corrected_population[i][j] += ra * (upper_bound - lower_bound) * (2 * np.random.uniform(0, 1) - 1)
    return corrected_population


# Reorganize hunting group
def reorganize_hunting_group(population, leader, alpha, beta, en, lower_bound, upper_bound):
    new_population = population.copy()
    for i in range(1, len(population)):  # Leader keeps its position
        for j in range(len(population[i])):
            rand_uniform = np.random.uniform(0, 1)
            new_population[i][j] = leader[j] + alpha * rand_uniform * (upper_bound - lower_bound) * (
                        2 * np.random.uniform(0, 1) - 1) / (en + beta)
    return new_population


# Hunting Search Optimization
def algm(c_i,opt_nodes,energy,bs,round,n_nodes,Dis, neigh, data_pack,x_value,y_value):
    # Algorithm parameters
    hgs = 30  # Hunting group size
    mml = 0.1  # Maximum movement toward the leader (varies between 0.05 and 0.4)
    hgcr = 0.3  # Hunting group consideration rate (varies between 0 and 1)
    dim = 5  # Dimensionality of the problem
    lower_bound = c_i
    upper_bound = 10
    max_iter = 100  # Maximum number of iterations
    epsilon = 0.01  # Preset constant for reorganization
    alpha = 0.5  # Positive real value determining global convergence rate
    beta = 0.1  # Positive real value determining global convergence rate
    # Initialize hunting group
    population = initialize_population(hgs, dim, lower_bound, upper_bound)
    # fitness = evaluate_population(population)
    data, label = [], []  ##### intialize data and label
    data.append(0.0)
    fit = fitness1.fitness_(population, opt_nodes, energy, bs, round, n_nodes, Dis, neigh, data_pack,
                           data, label, x_value,y_value)
    leader_idx = np.argmin(fit)
    leader = population[leader_idx]
    en = 0  # Epoch counter

    for t in range(max_iter):
        # Step 3: Move toward the leader
        population = move_toward_leader(population, leader, mml)

        # Evaluate new population
        fitness = evaluate_population(population)

        # Update the leader
        current_leader_idx = np.argmin(fitness)
        current_leader = population[current_leader_idx]

        if fitness[current_leader_idx] < fitness[leader_idx]:
            leader_idx = current_leader_idx
            leader = current_leader

        # Step 4: Position correction
        population = position_correction(population, hgcr,upper_bound,lower_bound)

        # Check for reorganization
        if np.abs(fitness[leader_idx] - np.max(fitness)) < epsilon:
            en += 1
            population = reorganize_hunting_group(population, leader, alpha, beta, en, lower_bound, upper_bound)

        print(f"Iteration {t + 1}/{max_iter}, Best Fitness: {fitness[leader_idx]}")

        # Termination criterion
        if np.abs(fitness[leader_idx] - np.max(fitness)) < epsilon:
            print("Termination criterion met. Ending search.")
            break

    return leader


