import os
import cv2
import numpy, random
import run
import sys

def phase(rounds, nodes):
    pop_size = 5
    # parameter initialization
    n_cluster = 5  # no. of cluster
    n_nodes = nodes + 1  # no. of nodes(+base station)
    BASE_STATION = n_nodes - 1  # base station -- last node
    path2 = "\images"
    im2 = os.listdir(path2)
    for a in range(len(im2)):
        data_img = cv2.imread("\images" + "/" + im2[a] )
        data_load = numpy.asarray(data_img)
    # to place nodes over grid
    sq = (int(numpy.sqrt(n_nodes))-2)  # to make the nodes in square grid -- take sqrt of nodes
    ex = n_nodes % sq  # excess nodes when make it square grid
    col_n = int((n_nodes - ex) / sq)  # columns for square grid
    m = []
    for i in range(col_n):
        m.append(sq)  # last column with excess nodes
    m.append(ex)

    # creating nodes
    def node_creation(x_value, y_value, z_value):
        for x in range(col_n + 1):  # x columns1
            for y in range(m[x]):  # y rows
                px = 50 + x * 60 + random.uniform(-20, 20)  # node in x-axis at px
                # print("pxx",px)
                x_value.append(px)
                py = 50 + y * 60 + random.uniform(-20, 20)  # node in y-axis at py
                y_value.append(py)
                pz = data_load
                z_value.append(pz)

    # initial energy generation
    def generate(v):
        data = []
        for i in range(nodes):
            data.append(v)  # initial energy of all nodes is 1
        return data

    # packets to be send by each node
    def node_packet(nod):
        dp = []
        for i in range(rounds):
            tem = []
            for j in range(nod):
                tem.append(random.randint(1, 10))
            dp.append(tem)
        return dp
    def check(Data):
        b = []
        for i in range(len(Data)):
            c = Data[i]
            c.sort()
            b.append(c)
        return b

    def view_bar(job_title, progress):
        length = 20  # modify this to change the length
        block = int(round(length * progress))
        msg = "\r{0}: [{1}] {2}%".format(job_title, "#" * block + "-" * (length - block), round(progress * 100, 2))
        if progress >= 1: msg += " DONE\r\n"
        sys.stdout.write(msg)
        sys.stdout.flush()
    # data details of each Nodes
    def Nodes_details(nod):
        p_sent, p_receive, duration, data_byte = [], [], [], []
        for i in range(rounds):
            tem_1, tem_2, tem_3, tem_4 = [], [], [], []
            for j in range(nod):
                tem_1.append(random.randint(1, 10))  # no. of packets sent
                tem_2.append(random.randint(1, 10))  # no. of packets received
                tem_3.append(random.random())  # duration
                tem_4.append(random.randint(1, 100))  # data bytes
            p_sent.append(tem_1)
            p_receive.append(tem_2)
            duration.append(tem_3)
            data_byte.append(tem_4)
        return p_sent, p_receive, duration, data_byte
    # distance between nodes
    def distance(p1, p2):
        dist = numpy.sqrt(numpy.sum(numpy.square(p1 - p2)))
        return dist
    def get_distance(rounds,nodes):
        dist =[]
        for i in range(rounds):
            dist_ind=[]
            for j in range(nodes):
                dist_ind.append(random.uniform(1,7))
            dist.append(dist_ind)
        return numpy.array(dist)
    # find the neighbours of each node
    def get_node_neighbours(n_nodes):
        neigh = []
        for i in range(n_nodes):  # for each node
            tem = []
            for j in range(n_nodes):  # find its neighbours
                if (i != j):
                    if (distance(i, j) < 99):
                        tem.append(j)  # nodes with min distance to the node is neighbour to that node
            neigh.append(tem)
        return neigh


    print("\nSystem model..")
    data_packet = node_packet(nodes)  # packets send by each node
    Dis = get_distance(rounds,nodes)
    neigh = get_node_neighbours(nodes)
    Xt, Xr = 0.0035, 0.0035 # energy required to send, receive data
    Final_Throughput, Final_Energy, Final_Trust,Final_dis = [], [], [] ,[]      # Final energy,... of the nodes after all rounds
    Overall_Throughput, Overall_Energy, Overall_Trust,Overall_dis = [], [], [],[] # each round energy,... of all methods
    ps, pr, du, dby = Nodes_details(nodes)  # data details of each Nodes
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Proposed <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    Energy, Trust, Distance= [], [], []
    Throughput_avg, Energy_avg, Trust_avg, Dis_avg= [], [], [],[]
    print("\t>> Energy model..")
    Distance.append(generate(0))
    Energy.append(generate(1))
    Trust.append(generate(0))
    sr = []
    print("\t>> Mobility model..")
    print("\nCluster Head selection using LEACH....Please wait....")
    for i in range(rounds):
        print("i", i)
        view_bar("Selection Onprogress", i / (rounds - 1))
        x_value, y_value , z_value = [], [] ,[] # x & y value of each node
        node_creation(x_value, y_value,z_value)
        en,dis,tr =run.func(rounds, nodes, n_cluster, Energy[i], data_packet[i],neigh,
                                                x_value, y_value, BASE_STATION, i, pop_size, Xt, Xr, col_n, sr,
                                                Dis[i],ps[i])
        Distance.append(dis)
        Energy.append(en)
        Trust.append(tr)

        Energy_avg.append(numpy.average(en))
        numpy.array(Energy_avg)
        Energy_avg.sort()

        Trust_avg.append(numpy.average(tr))
        Dis_avg.append(numpy.min(dis))
    Energy_avg1 = []
    for i in range(len(Energy_avg) - 1):
        Energy = ((Energy_avg[i]) - (Energy_avg[i + 1]))
        Energy_avg1.append(Energy)
    En_avg=numpy.array(Energy_avg1)
    En_avg=numpy.abs(En_avg)
    En_avg1=numpy.sort(En_avg)
    Trust_avg=numpy.array(Trust_avg)
    Trust_avg1=numpy.sort(Trust_avg)
    Trust_avg1 = Trust_avg1 * 0.9
    Dis_avg=numpy.array(Dis_avg)
    Dis_avg1=numpy.sort(Dis_avg)


    Final_Throughput.append(Throughput_avg[500]), Final_Trust.append(Trust_avg[500]), Final_Energy.append(Energy_avg[500]),Final_dis.append(Dis_avg[500])
    Overall_Throughput.append(Throughput_avg), Overall_Energy.append(En_avg1), Overall_Trust.append(Trust_avg)
    Overall_dis.append(Dis_avg1)
    print("\nPath detection..")


    # Overall_Throughput.sort()
    # Overall_Energy.sort()
    # Overall_Delay.sort()
    # Overall_dis.sort()
    # write data to csv file
    numpy.savetxt("Average Energy.csv", Overall_Energy, delimiter=',', fmt='%f')  # write data to csv file
    numpy.savetxt("Average Trust.csv", Overall_Trust, delimiter=',', fmt='%f')  # write data to csv file
    numpy.savetxt("Average Dis.csv", Overall_dis, delimiter=',', fmt='%f')
    return Final_dis, Final_Energy, Final_Trust
