
import random,numpy as np
Enery_dep,Overall_dep=[],[]
# import Main.DRNN
import math

def Direct_trust(nodes,ED,Overall_dep,FP):
    DT=1-((Overall_dep[nodes])-ED[nodes]*FP[nodes])/(Overall_dep[nodes])
    return DT

def Indirect_trust(neigh_node,node,DT):
    dt_nc_i=0
    for i in range(len(neigh_node)):
        dt_nc_i+= DT[neigh_node[i]]*DT[node]
    dt_i=0
    for i in range(len(neigh_node)):
        dt_i+= DT[neigh_node[i]]
    IT = dt_nc_i/dt_i
    return IT

# summation of node energy
def calc_energy(nodes, en):
    en_summ = 0
    for i in range(len(nodes)):
        en_summ += en[i]
    return en_summ

 # calculate depletion
def calc_depletion(np,data_pack):
    # energy drop for all nodes
    for ed in range(np):
        y = data_pack[ed]  # Packet
        Es = (440 * 5) * (y / 6e6)
        Enery_dep.append(Es)
        Overall_dep.append(1 - Es)


def calc_trust(node_neigh,nodes,Enery_dep,Overall_dep,ps,trust):
    NF=500
    DT,IT,RT,AF=[],[],[],[]
    for i in range(nodes):
        DT.append(Direct_trust(i,Enery_dep,Overall_dep,ps))
    for i in range(nodes):
        IT.append(Indirect_trust(node_neigh[i],i,DT))

    T=[]
    for ij in range(nodes):
        t = ((1/2)*(DT[ij])+IT[ij]) # trust
        T.append(trust[ij]-t)
    trust = np.mean(T)
    return trust

# delay calculation
def calc_delay(nodes_ch,nodes):
    s = 0
    for i in range(len(nodes_ch)):
        s += (len(nodes_ch[i])) / nodes
    Delay = s
    return Delay

def distance(p1, p2):
    dist = np.sqrt(np.sum(np.square(p1 - p2)))
    return dist

def power(nodes, en):
    En = []
    for i in range(len(nodes)):
        En.append(en[nodes[i]])
    Pm = np.mean(En)  # power -> constant between transmitter and receiver
    return Pm


def dist(nodes, x, y):
    D = []
    for i in range(len(nodes)):
        D.append(distance(i, i + 1, x, y))  # distance between nodes
    Dis = np.mean(D)
    return Dis

# grouping nodes
def group_nodes(nodes, cg):
    nodes_clustered = []
    for i in range(len(nodes)):
        tem = []
        for j in range(len(cg) - 1):  # -1, since last node is base station
            # if (i == cg[j].any()):  # node in that cluster
            if (i == cg[j]):
                tem.append(j)
        nodes_clustered.append(tem)  # group nodes in same cluster
    return nodes_clustered


# Node grouping
def node_clustering(opt_node, CH, bs):
    clustered = []
    for i in range(len(opt_node)):
        tem = []  # tem array to store the distance value
        for j in range(len(CH)):
            tem.append(distance(opt_node[i], CH[j]))  # distance calculation between cluster head & nodes except base station
        min_index = np.argmin(tem)
        clustered.append(CH[min_index])  # grouped cluster head is added
    clustered.append(bs)  # added base station at last separately
    return clustered

def throughput(E,data_pkt):
    tp=0
    for i in range(len(data_pkt)):
        tp = tp +((E[i]*len(data_pkt))/data_pkt[i])
    return tp

# calculation of Link quality
def Link_quality(nodes, en, x, y):
    Pm = power(nodes, en)
    D = dist(nodes, x, y)
    Lq = Pm / D
    return Lq

# Distance Calculation
def calc_dist(opt_node,CH,d):
    NF=100
    summ = 0
    for i in range(len(opt_node)):
        s = 0
        for j in range(len(CH)):
            s += distance(opt_node[i], CH[j])  # distance calculation between cluster head & nodes
        summ += s
    D=summ/NF
    return D

def Link_life_time(A,B,X,Y):
    pi = 180
    r = random.random()
    llt =[]
    for i in range(len(A)):
        Va,Ta,Xa,Ya =A[i],random.uniform(0,(2*pi)),X[i],Y[i]
        Vb,Tb,Xb,Yb =B[i],random.uniform(0,(2*pi)),X[i],Y[i]
        a = Va *math.cos(Ta) - Vb *math.cos(Tb)
        b = Xa - Xb
        c =Va*math.sin(Ta) - Vb*math.sin(Tb)
        d = Ya - Yb

        res = (-(a*b + c*d)+math.sqrt((a**2+c**2)*(r**2)-(a*d-c*b)**2))/(a**2+c**2)
        llt.append(res)
    return min(llt)

def fitness_(soln,opt_nodes,energy,bs, round, n_nodes,Dis, neigh, data_pack,data,label,ps,y_value):
    Fit = []
    calc_depletion(n_nodes,data_pack)
    # E = calc_trust(neigh, n_nodes, Enery_dep, Overall_dep, ps, data_pack)
    E = calc_energy(opt_nodes, energy)
    data.append(E), label.append(E)

    for i in range(len(opt_nodes)):
        Distance = calc_dist(opt_nodes,soln[i],Dis)
        Th = throughput(energy,data_pack)
        E = calc_energy(opt_nodes, energy)  # energy
        T = calc_trust(neigh,opt_nodes,Enery_dep,Overall_dep,ps,Th)
        L = Link_quality(opt_nodes,E,ps,y_value)
        fit = 1/4 * ((1-E)+(1-Distance)+(1-Distance)+T+L)
        f = np.array([fit])
        Fit.append(min(f))
        # Fit.append(min(fit))

    return Fit

