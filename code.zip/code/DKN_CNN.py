import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.linear_model import LinearRegression

def process(Data,Label,l1):

    # -------------------------------calculating weight------------------------------

    opt = tf.keras.optimizers.legacy.RMSprop()  #### weight
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(2)])
    m.compile(opt, loss='mse')
    Data = Data * 100
    m.fit(Data.astype('int'), Label)  # Training.
    w1 = m.get_weights()[0]
    w2 = m.get_weights()[1]

    # -----------------------------------------------------------

    f1 = Data[:,:10]
    f2 = Data[:,10:20]
    f3 = Data[:,20:]
    y,y1,y2=[],[],[]

    for j in range(f3.shape[0]):
        z2 = []
        for k in range(f3.shape[1]):
            z2.append(f3[j][k] * w1[k][0])
        y2.append(z2)

    for j in range(f2.shape[0]):
        z1 = []
        for k in range(f2.shape[1]):
            z1.append(f2[j][k] * w1[k][0])
        y1.append(z1)

    for j in range(f1.shape[0]):
        z = []
        for k in range(f1.shape[1]):
            z.append(f1[j][k] * w1[k][0])
        y.append(z)

    y=np.array(y)
    y1=np.array(y1)
    y2=np.array(y2)

    alpha = 0.2
    l2 = alpha * y + (1 / 2) * alpha * y1 + (1 / 6) * (1-alpha) * y2 + 1/24 * alpha * (1-alpha) * (2-alpha) * l1

    # -----------------------------------------fusion-regression-----------------------------------------------

    reg = LinearRegression().fit(l1, Label)
    Prediction = reg.predict(l1)
    pre = np.resize(Prediction, (len(l2), 1))
    l3 = np.concatenate((l2, pre), axis=1)
    return l3