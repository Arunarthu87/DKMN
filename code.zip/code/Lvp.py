import cv2, math
import numpy as np
import matplotlib.pyplot as plt
import warnings, sys, os

if not sys.warnoptions:
    warnings.simplefilter("ignore")
    os.environ["PYTHONWARNINGS"] = "ignore"  # Also affect subprocesses
from warnings import simplefilter
from sklearn.exceptions import ConvergenceWarning

simplefilter("ignore", category=ConvergenceWarning)


def get_pixel_lvp(img, center, x, y):
    new_value = 0
    try:
        if img[x][y] >= center:
            new_value = 1
    except:
        pass
    return new_value



def local_vector_patterns( img, x, y):
    center = img[x][y]
    val_ar = []
    val_ar.append(get_pixel_lvp(img, center, x - 1, y + 1))  # top_right
    val_ar.append(get_pixel_lvp(img, center, x, y + 1))  # right
    val_ar.append(get_pixel_lvp(img, center, x + 1, y + 1))  # bottom_right
    val_ar.append(get_pixel_lvp(img, center, x + 1, y))  # bottom
    val_ar.append(get_pixel_lvp(img, center, x + 1, y - 1))  # bottom_left
    val_ar.append(get_pixel_lvp(img, center, x, y - 1))  # left
    val_ar.append(get_pixel_lvp(img, center, x - 1, y - 1))  # top_left
    val_ar.append(get_pixel_lvp(img, center, x - 1, y))  # top

    power_val = [1, 2, 4, 8, 16, 32, 64, 128]
    P = len(power_val)  ## number of neighbours
    val_V_rp = 0
    val_lbp = 0
    ### V R,P(Ic) ###
    for i in range(len(val_ar)):
        val_V_rp += (val_ar[i] * power_val[i]) ** 2  # phi (Ip,Ic,P)^2
        val_lbp += (val_ar[i] * power_val[i])
    feat = (P * val_lbp - val_lbp ** 2) / P ** 2

    return feat

def lvp(IM_11):
    height, width = IM_11.shape
    img_LVP = np.zeros((height, width, 3), np.uint8)

    for i in range(height):
        for j in range(width):
            # print('ij', i, j)
            ######### LVP#########
            img_LVP[i, j] = local_vector_patterns( IM_11, i, j)  # org image, gray image
    hist_lvp = cv2.calcHist([img_LVP], [0], None, [10], [0, 10])
    return hist_lvp.flatten()