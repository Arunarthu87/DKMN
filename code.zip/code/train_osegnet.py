
from keras_segmentation.models.denseunet import dunet_mini

new_model = dunet_mini( n_classes=2,input_height=256,input_width=256)
new_model.train(
    train_images =  r"\trainimages",        # train images
    train_annotations = r"\maskimages",     # mask iamges
    checkpoints_path = "osegnet" , epochs=10
)



