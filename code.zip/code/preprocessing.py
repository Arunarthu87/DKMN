
import cv2
import numpy as np
import os
from scipy import ndimage
from keras_segmentation.models.osegnet import osegnet
import Lvp,WLBP,CLBP,DKN,Routing
rounds, nodes=500,50
dis,en,tru=Routing.phase(rounds, nodes)         # routing
def process():
    feat_all, lab, inp = [], [], []
    path = r'Data'
    lst = os.listdir(path)
    for i in range(len(lst)):
        path1 = path + '\\' + lst[i]
        lst1 = os.listdir(path1)
        for j in range(len(lst1)):
            path2 = path1 + '\\' + lst1[j]
            img = cv2.imread(path2)
            img = cv2.resize(img,(256,256))

            #---------------------------preprocessing------------------------

            processed = ndimage.median_filter(img, size=20)
            hist_p = cv2.calcHist([processed], [0], None, [10], [0, 10])
            inp.append(hist_p)

            #----------------------------segmentation------------------------

            new_model = osegnet(n_classes=2)
            new_model.load_weights(r'osegnet.00010')
            seg = new_model.predict_segmentation(inp=processed)

            #---------------------------feature extraction----------------------

            f1 = WLBP.w_l_b_p(seg)
            f2 = CLBP.main(seg)
            f3 = Lvp.lvp(seg)
            feat =[f1,f2,f3]
            feat_all.append(feat)
            lab.append(i)
            np.savetxt("feature.csv", feat_all, delimiter=',', fmt="%s")
            np.savetxt("label.csv", lab, delimiter=',', fmt="%s")
    return feat_all,lab,inp

Acc,Sen,Spe=[],[],[]
tr=0.9
feat, cls,inp = process()
DKN.algm(feat,inp,cls,tr,Acc,Sen,Spe)       # proposed



